import pygame
import sys
from settings import Settings
from button import Button
from game_stats import GameStats
from altman import Altman
from monster import Monster
from pygame.sprite import Group
import game_functions as gf
from scoreboard import Scoreboard
def run_game():
    #初始化游戏并创建一个屏幕对象
    pygame.init()#初始化背景设置
    ai_settings = Settings()#全局设置
    screen = pygame.display.set_mode( #创建screen显示窗口
        (ai_settings.screen_width,ai_settings.screen_height))
    pygame.display.set_caption("Altman beat monster")#标题
    #新建Play按钮
    play_button = Button(ai_settings,screen,"Play")
    #创建一个用于存储游戏统计信息的实例
    stats = GameStats(ai_settings)
    sb = Scoreboard(ai_settings, screen, stats)
    #创建一个奥特曼
    altman = Altman(ai_settings,screen)
    #创建一个用于存储射线的编组
    rays = Group()
    #创建一个怪兽编组
    monsters = Group()
    #创建怪兽群
    gf.create_fleet(ai_settings,screen,altman,monsters)
    #开始游戏的主循环
    while True:
        #监视键盘和鼠标事件
        gf.check_events(ai_settings,screen,stats,sb,play_button,altman,monsters,rays)
        if stats.game_active:
            #移动奥特曼
            altman.update()
            #更新射线位置
            gf.update_rays(ai_settings,screen,stats,sb,altman,monsters,rays)
            #更新怪兽
            gf.update_monsters(ai_settings,stats,screen,sb,altman,monsters,rays)
            #更新屏幕
            gf.update_screen(ai_settings,screen,stats,sb,altman,monsters,rays,play_button)
run_game()
