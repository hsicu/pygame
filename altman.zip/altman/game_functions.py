import sys
from time import sleep
import pygame
from ray import Ray
from monster import Monster
def check_events(ai_settings,screen,stats,sb,play_button,altman,monsters,rays):
    """响应按键和鼠标事件"""
    for event in pygame.event.get():
        if event.type == pygame.QUIT:#关闭窗口退出
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            check_keydown_events(event,ai_settings,screen,altman,rays)
        elif event.type == pygame.KEYUP:
            check_keyup_events(event,altman)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            check_play_button(ai_settings,screen,stats,sb,play_button,altman,monsters,rays,mouse_x, mouse_y)
  
def check_play_button(ai_settings,screen,stats,sb,play_button,altman,monsters,rays,mouse_x,mouse_y):
    """在玩家单击Play按钮时开始游戏"""
    button_clicked = play_button.rect.collidepoint(mouse_x,mouse_y)
    if button_clicked and not stats.game_active:
        #重置游戏设置
        ai_settings.initialize_dynamic_settings()
 
        #隐藏光标
        pygame.mouse.set_visible(False)
        #重置游戏统计信息
        stats.reset_stats()
        stats.game_active = True
 
        #重置计分牌图像
        sb.prep_score()
        sb.prep_high_score()
        sb.prep_level()
        sb.prep_altmans()
        
        #清空怪兽列表和射线列表
        monsters.empty()
        rays.empty()
 
        #创建一群新的怪兽，并让奥特曼居中
        create_fleet(ai_settings,screen,altman,monsters)
        altman.center_altman()
def update_screen(ai_settings,screen,stats,sb,altman,monsters,rays,play_button):
    """更新屏幕上的图像，并切换到新屏幕"""
    #每次循环时都重绘屏幕
    screen.fill(ai_settings.bg_color)
    altman.blitme()
    monsters.draw(screen)
     #在奥特曼和怪兽后面重绘所有射线
    for ray in rays.sprites():
        ray.draw_ray()# 绘制射线
         #显示得分
        sb.show_score()
        #如果游戏处于非活跃状态，就显示Play按钮
        if not stats.game_active:
            play_button.draw_button()
    #让最近绘制的屏幕可见
    pygame.display.flip()
def check_keydown_events(event,ai_settings,screen,altman,rays):
    """响应按键"""
    if event.key == pygame.K_RIGHT:
        altman.moving_right = True
    elif event.key == pygame.K_LEFT:
        altman.moving_left = True
    elif event.key == pygame.K_SPACE:
        fire_ray(ai_settings,screen,altman,rays)
    elif event.key == pygame.K_q:
        sys.exit()
def fire_ray(ai_settings,screen,altman,rays):
    """如果还没有到达限制，就发射一个射线"""
    #创建新射线并将其加入到编组rays中
    if len(rays) < ai_settings.rays_allowed:
        new_ray = Ray(ai_settings,screen,altman)
        rays.add(new_ray)
def check_keyup_events(event,altman):
    """响应松开"""
    if event.key == pygame.K_RIGHT:
        altman.moving_right = False
    elif event.key == pygame.K_LEFT:
        altman.moving_left = False

def update_rays(ai_settings,screen,stats,sb,altman,monsters,rays):
    """更新射线的位置，并删除已消失的射线"""
    #更新射线的位置
    rays.update()
    #删除已消失的射线
    for ray in rays.sprites():
        if ray.rect.bottom <= 0:
            rays.remove(ray)
    check_ray_monster_collisions(ai_settings,screen,stats,sb,altman,monsters,rays)
def check_ray_monster_collisions(ai_settings,screen,stats,sb,altman,monsters,rays):
    """响应射线和怪兽的碰撞"""
    #删除发生碰撞的射线和怪兽
    collisions = pygame.sprite.groupcollide(rays,monsters,True,True)
    if collisions:
        for monsters in collisions.values(): 
            stats.score += ai_settings.monster_points * len(monsters)
            sb.prep_score()
            check_high_score(stats,sb)
    if len(monsters) == 0:
        #删除现有的射线并新建一群怪兽
        rays.empty()
        ai_settings.increase_speed()
 
        #提高等级
        stats.level += 1
        sb.prep_level()
 
        create_fleet(ai_settings,screen,altman,monsters)
def get_number_monsters_x(ai_settings,monster_width):
    """计算每行可容纳多少个怪兽"""
    available_space_x = ai_settings.screen_width - 2 * monster_width
    number_monsters_x = int(available_space_x / (2 * monster_width))
    return number_monsters_x
def get_number_rows(ai_settings,altman_height,monster_height):
    """计算屏幕可容纳多少行怪兽"""
    available_space_y = (ai_settings.screen_height-(3*monster_height)-altman_height)
    number_rows = int(available_space_y / (2*monster_height))
    return number_rows
def creat_monster(ai_settings,screen,monsters,monster_number,row_number):   
        """创建一个怪兽并将其加入当前行"""
        monster = Monster(ai_settings,screen)
        monster_width = monster.rect.width
        monster.x = monster_width + 2 * monster_width * monster_number
        monster.rect.x = monster.x
        monster.rect.y = monster.rect.height + 2*monster.rect.height*row_number
        monsters.add(monster)
def create_fleet(ai_settings,screen,altman,monsters):
    """创建怪兽群"""
    #创建一个怪兽，并计算一行可容纳多少个怪兽
    #怪兽间距为怪兽宽度
    monster = Monster(ai_settings,screen)
    number_monsters_x = get_number_monsters_x(ai_settings,monster.rect.width)
    number_rows = get_number_rows(ai_settings,altman.rect.height,monster.rect.height)
    #创建第一行怪兽
    for row_number in range(number_rows):
        for monster_number in range(number_monsters_x):
            #创建一个怪兽加入当前行
            creat_monster(ai_settings,screen,monsters,monster_number,row_number)
def check_fleet_edges(ai_settings,monsters):
    """有怪兽到达边缘时采取相应的措施"""
    for monster in monsters.sprites():
        if monster.check_edges():
            change_fleet_direction(ai_settings,monsters)
            break
def change_fleet_direction(ai_settings,monsters):
    """将整群怪兽下移，并改变它们的方向"""
    for monster in monsters.sprites():
        monster.rect.y += ai_settings.fleet_drop_speed
    ai_settings.fleet_direction *= -1
def altman_hit(ai_settings,stats,screen,sb,altman,monsters,rays):
    """响应被怪兽撞到的奥特曼"""
    if stats.altmans_left > 0:
        #将altmans_left减1
        stats.altmans_left -= 1
        #更新记分牌
        sb.prep_altmans()
        #清空怪兽和射线列表
        monsters.empty()
        rays.empty()
        #创建一群新的怪兽，并将奥特曼放到屏幕底端中央
        create_fleet(ai_settings,screen,altman,monsters)
        altman.center_altman()
        #暂停
        sleep(0.5)
    else:
        stats.game_active = False
        pygame.mouse.set_visible(True)
def check_monsters_bottom(ai_settings,stats,screen,sb,altman,monsters,rays):
    """检查是否有怪兽到达了屏幕底端"""
    screen_rect = screen.get_rect()
    for monster in monsters.sprites():
        if monster.rect.bottom >= screen_rect.bottom:
            #像奥特曼被撞到一样进行处理
            altman_hit(ai_settings,stats,screen,sb,altman,monsters,rays)
            break
def update_monsters(ai_settings,stats,screen,sb,altman,monsters,rays):
    """检查是否有怪兽位于屏幕边缘，并更新整群怪兽的位置"""
    check_fleet_edges(ai_settings,monsters)
    monsters.update()
    #检查怪兽和奥特曼之间的碰撞
    if pygame.sprite.spritecollideany(altman,monsters):
        altman_hit(ai_settings,stats,screen,sb,altman,monsters,rays)
    #检查是否有怪兽到达屏幕底端
    check_monsters_bottom(ai_settings,stats,screen,sb,altman,monsters,rays)
def check_high_score(stats,sb):
    """检查是否诞生了新的最高纪录"""
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sb.prep_high_score()    
